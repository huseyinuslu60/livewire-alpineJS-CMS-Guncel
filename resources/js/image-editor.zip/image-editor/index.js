/**
 * Image Editor - Main Entry Point
 * Combines all modules into a single Alpine.js component
 */

import { createInitialState } from './state.js';
import { createCanvasMethods } from './canvas.js';
import { createImageLoaderMethods } from './image-loader.js';
import { createSpotDataMethods } from './spot-data.js';
import { createTextMethods } from './text.js';
import { createEffectsMethods } from './effects.js';
import { createHistoryMethods } from './history.js';
import { createSaveMethods } from './save.js';
import { createToolsMethods } from './tools.js';
import { createEventsMethods } from './events.js';

/**
 * Register Image Editor Alpine.js component
 */
export function registerImageEditor() {
  // Alpine.js is loaded globally in app.js, we'll access it from window
  // This function is called after Alpine is initialized (in alpine:init event)
  const Alpine = window.Alpine;

  if (!Alpine) {
    console.error('Alpine.js is not loaded. Make sure app.js is loaded first.');
    return;
  }

  // Global helper function to open image editor
  if (typeof window !== 'undefined') {
    window.openImageEditor = function(index, url, spotData = null) {
      // Try to find the editor instance
      const editorEl = document.querySelector('[x-data*="imageEditor"]');
      if (editorEl && editorEl._x_dataStack && editorEl._x_dataStack[0]) {
        editorEl._x_dataStack[0].openEditor(index, url, spotData);
        return;
      }

      // Fallback: use global reference
      if (window.postsImageEditor && typeof window.postsImageEditor.openEditor === 'function') {
        window.postsImageEditor.openEditor(index, url, spotData);
        return;
      }

      // Last resort: dispatch event
      window.dispatchEvent(new CustomEvent('open-image-editor', {
        detail: { index, url, spotData }
      }));
    };
  }

  // Create Alpine.js component by combining all modules
  window.Alpine.data('imageEditor', () => {
    // Initialize state
    const state = createInitialState();

    // Combine all method modules
    const methods = {
      ...createCanvasMethods(),
      ...createImageLoaderMethods(),
      ...createSpotDataMethods(),
      ...createTextMethods(),
      ...createEffectsMethods(),
      ...createHistoryMethods(),
      ...createSaveMethods(),
      ...createToolsMethods(),
      ...createEventsMethods(),

      /**
       * Initialize component
       */
      init() {
        this.setupKeyboardShortcuts();

        // Set global reference immediately
        if (typeof window !== 'undefined') {
          window.postsImageEditor = this;
        }
      },

      /**
       * Open image editor with image and optional spot_data
       * @param {string|number} identifier - File ID or index
       * @param {string} url - Image URL
       * @param {object|null} spotData - Spot data containing saved edits
       */
      openEditor(identifier, url, spotData = null) {
        // IMPORTANT: If spotData is provided, use original image path from spotData
        // The url parameter might be the edited preview, but we always want to load the original
        let imageUrlToUse = url;

        if (spotData && spotData.image && spotData.image.original && spotData.image.original.path) {
          // Use original image path from spot_data
          const originalPath = spotData.image.original.path;

          // Convert relative path to full URL if needed
          if (!originalPath.startsWith('http') && !originalPath.startsWith('data:')) {
            // Handle storage paths
            if (originalPath.startsWith('storage/') || originalPath.startsWith('/storage/')) {
              imageUrlToUse = window.location.origin + (originalPath.startsWith('/') ? '' : '/') + originalPath;
            } else if (!originalPath.startsWith('/')) {
              // Relative path without storage prefix
              imageUrlToUse = window.location.origin + '/storage/' + originalPath;
            } else {
              // Absolute path
              imageUrlToUse = window.location.origin + originalPath;
            }
          } else {
            imageUrlToUse = originalPath;
          }

          console.log('Image Editor - openEditor: Using original image from spot_data', {
            originalPath: originalPath,
            imageUrlToUse: imageUrlToUse,
            urlParameter: url,
          });
        } else if (!url) {
          console.error('ImageEditor: URL is required');
          return;
        }

        console.log('Image Editor - openEditor called:', {
          identifier: identifier,
          identifier_type: typeof identifier,
          url: url,
          imageUrlToUse: imageUrlToUse,
          spotData: spotData,
        });

        // Initialize editor state
        this.isOpen = true;
        this.setIdentifier(identifier, spotData);
        this.resetEditorState(imageUrlToUse);

        // Load spot_data if available
        if (spotData && spotData.image) {
          this.loadSpotData(spotData);
        } else {
          this.resetSpotData(imageUrlToUse);
        }

        // Reset UI state
        this.layers = [];
        this.activeTool = 'select';
        this.selectedTemplate = null;

        // Reset filters only if no spot_data (new image)
        if (!spotData || !spotData.image) {
          this.resetFilters();
        }

        // Set global reference
        if (typeof window !== 'undefined') {
          window.postsImageEditor = this;
        }

        // Initialize canvas after DOM is ready
        this.$nextTick(() => {
          this.initCanvas();
        });
      },

      /**
       * Set identifier (fileId or index) based on context
       */
      setIdentifier(identifier, spotData) {
        if (identifier === null || identifier === undefined || identifier === '') {
          this.currentIndex = null;
          this.currentFileId = null;
          return;
        }

        const numIdentifier = typeof identifier === 'string' ? parseInt(identifier, 10) : identifier;

        // If we have spot_data, treat as fileId (edit page)
        if (spotData && spotData.image) {
          this.currentFileId = String(identifier);
          this.currentIndex = null;
        } else if (!isNaN(numIdentifier) && numIdentifier.toString() === String(identifier) && String(identifier).length <= 3) {
          // Small number = index (create page)
          this.currentIndex = numIdentifier;
          this.currentFileId = null;
        } else {
          // String = fileId
          this.currentFileId = String(identifier);
          this.currentIndex = null;
        }

        console.log('Image Editor - Identifier set:', {
          currentIndex: this.currentIndex,
          currentFileId: this.currentFileId,
        });
      },

      /**
       * Reset editor state for new session
       */
      resetEditorState(url) {
        this.imageUrl = url;
        this.zoom = 1;
        this.panX = 0;
        this.panY = 0;
        this.history = [];
        this.historyIndex = -1;
      },

      /**
       * Close editor
       */
      closeEditor() {
        this.isOpen = false;
        this.canvas = null;
        this.ctx = null;
        this.image = null;
        this.currentIndex = null;
        this.currentFileId = null;
        this.imageUrl = null;
        this.editingText = false;
        // Reset crop data and original dimensions
        this.desktopCrop = [];
        this.mobileCrop = [];
        this.originalImageWidth = 0;
        this.originalImageHeight = 0;
        this.originalImagePath = null;
      },

      /**
       * Draw main canvas (combines all drawing operations)
       */
      draw() {
        if (!this.ctx || !this.image) {
          console.warn('Image Editor - draw: Canvas or image not ready', {
            hasCtx: !!this.ctx,
            hasImage: !!this.image,
            canvasSize: { width: this.canvas?.width, height: this.canvas?.height },
          });
          return;
        }

        // Update canvas transform (zoom and pan)
        this.updateCanvasTransform();

        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Draw background pattern (transparency indicator)
        this.drawCheckerboard();

        // Check if image already has effects applied (from crop operation)
        // If image was cropped, effects are already applied to the cropped image
        // Otherwise, apply effects via filter
        const hasCrop = this.desktopCrop && this.desktopCrop.length === 4;
        const imageAlreadyHasEffects = hasCrop; // Cropped images already have effects applied

        if (!imageAlreadyHasEffects) {
          // Apply global filters for non-cropped images
          this.ctx.save();
          const filterString = this.buildFilterString();
          if (filterString && filterString !== 'none') {
            this.ctx.filter = filterString;
          }
        }

        // Draw layers
        this.layers.forEach((layer, index) => {
          if (!layer.visible) return;

          this.ctx.save();
          this.ctx.globalAlpha = layer.opacity / 100;

          if (layer.type === 'image' && layer.image) {
            this.ctx.drawImage(layer.image, 0, 0, this.canvasWidth, this.canvasHeight);
          }

          this.ctx.restore();
        });

        if (!imageAlreadyHasEffects) {
          this.ctx.restore();
        }

        // Draw text objects
        if (this.textObjects && this.textObjects.length > 0) {
          this.textObjects.forEach((text, index) => {
            this.drawText(text, index === this.activeTextIndex);
          });
        }

        // Draw crop overlay
        if (this.isCropping) {
          this.drawCropOverlay();
        }

        // Draw selection
        if (this.selection) {
          this.drawSelection();
        }
      },

      /**
       * Text property update methods (for UI bindings)
       */
      changeTextColor(color) {
        if (this.activeTextIndex !== null) {
          this.textObjects[this.activeTextIndex].color = color;
          this.draw();
        } else {
          this.textColor = color;
        }
      },

      changeTextBackgroundColor(color) {
        if (this.activeTextIndex !== null) {
          this.textObjects[this.activeTextIndex].backgroundColor = color;
          // If color is transparent, set padding to 0, otherwise use default padding
          if (color === 'transparent' || !color) {
            this.textObjects[this.activeTextIndex].padding = 0;
          } else if (this.textObjects[this.activeTextIndex].padding === 0) {
            this.textObjects[this.activeTextIndex].padding = 15; // Default padding
          }
          this.draw();
          this.saveState();
        } else {
          this.textBackgroundColor = color;
        }
      },

      changeFontSize(size) {
        if (this.activeTextIndex !== null) {
          this.textObjects[this.activeTextIndex].fontSize = parseInt(size);
          this.draw();
        } else {
          this.fontSize = parseInt(size);
        }
      },

      changeFontFamily(family) {
        if (this.activeTextIndex !== null) {
          this.textObjects[this.activeTextIndex].fontFamily = family;
          this.draw();
        } else {
          this.fontFamily = family;
        }
      },

      updateTextProperty(property, value) {
        // Ensure numeric properties are stored as numbers
        const numericProperties = ['fontSize', 'letterSpacing', 'lineHeight', 'brushSize', 'brushOpacity', 'brushHardness'];
        if (numericProperties.includes(property)) {
          value = parseFloat(value) || (property === 'lineHeight' ? 1.2 : 0);
        }

        if (this.activeTextIndex !== null) {
          this.textObjects[this.activeTextIndex][property] = value;
          this.draw();
        } else {
          this[property] = value;
        }
      },

      updateTextShadow(property, value) {
        if (this.activeTextIndex !== null) {
          if (!this.textObjects[this.activeTextIndex].textShadow) {
            this.textObjects[this.activeTextIndex].textShadow = JSON.parse(JSON.stringify(this.textShadow));
          }
          this.textObjects[this.activeTextIndex].textShadow[property] = value;
          this.draw();
        } else {
          this.textShadow[property] = value;
        }
      },

      updateTextStroke(property, value) {
        if (this.activeTextIndex !== null) {
          if (!this.textObjects[this.activeTextIndex].textStroke) {
            this.textObjects[this.activeTextIndex].textStroke = JSON.parse(JSON.stringify(this.textStroke));
          }
          this.textObjects[this.activeTextIndex].textStroke[property] = value;
          this.draw();
        } else {
          this.textStroke[property] = value;
        }
      },

      /**
       * Utility: Convert hex to RGB
       */
      hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16)
        } : { r: 0, g: 0, b: 0 };
      },
    };

    // Return combined state and methods
    return {
      ...state,
      ...methods,
    };
  });
}

