/**
 * Image Editor - State Management
 * All state variables and initial state definitions
 */

export function createInitialState() {
  return {
    // Editor State
    isOpen: false,
    currentIndex: null,
    currentFileId: null,
    imageUrl: null,
    spotData: null, // Store spot_data for loading saved edits
    savedTextObjects: [], // Store textObjects from spot_data before scaling
    savedCanvasWidth: 0, // Store canvas width when textObjects were saved
    savedCanvasHeight: 0, // Store canvas height when textObjects were saved

    // Canvas
    canvas: null,
    ctx: null,
    image: null,
    canvasWidth: 800,
    canvasHeight: 600,

    // Layers System
    layers: [],
    activeLayerIndex: 0,

    // Tools
    activeTool: 'select', // select, crop, eraser, text, pan
    isDrawing: false,
    startX: 0,
    startY: 0,
    lastX: 0,
    lastY: 0,

    // Brush
    brushSize: 20,
    brushColor: '#000000',
    brushOpacity: 100,
    brushHardness: 50,

    // Text
    textColor: '#000000',
    textBackgroundColor: 'transparent',
    fontSize: 32,
    fontFamily: 'Arial',
    fontWeight: 'normal', // normal, bold, 100-900
    textBold: false,
    textItalic: false,
    textUnderline: false,
    textStrikethrough: false,
    textAlign: 'left', // left, center, right, justify
    letterSpacing: 0,
    lineHeight: 1.2,
    textShadow: {
      enabled: false,
      color: '#000000',
      blur: 0,
      offsetX: 0,
      offsetY: 0
    },
    textStroke: {
      enabled: false,
      color: '#000000',
      width: 1
    },
    textTransform: 'none', // none, uppercase, lowercase, capitalize
    textObjects: [],
    activeTextIndex: null,
    editingText: false,
    selectedTemplate: null, // Selected template for next text

    // Text Templates/Presets
    textTemplates: [
      {
        name: 'Sarı Metin',
        textColor: '#FFD700',
        fontSize: 48,
        fontFamily: 'Arial',
        fontWeight: 'bold',
        textBold: true,
        textItalic: false,
        textUnderline: false,
        textStrikethrough: false,
        textAlign: 'left',
        letterSpacing: 2,
        lineHeight: 1.2,
        textShadow: {
          enabled: true,
          color: '#000000',
          blur: 4,
          offsetX: 2,
          offsetY: 2
        },
        textStroke: {
          enabled: false,
          color: '#000000',
          width: 1
        },
        textTransform: 'none',
        backgroundColor: 'transparent',
        padding: 0
      },
      {
        name: 'Beyaz Metin - Koyu Arka Plan',
        textColor: '#FFFFFF',
        fontSize: 48,
        fontFamily: 'Arial',
        fontWeight: 'bold',
        textBold: true,
        textItalic: false,
        textUnderline: false,
        textStrikethrough: false,
        textAlign: 'left',
        letterSpacing: 1,
        lineHeight: 1.2,
        textShadow: {
          enabled: true,
          color: '#000000',
          blur: 6,
          offsetX: 3,
          offsetY: 3
        },
        textStroke: {
          enabled: false,
          color: '#000000',
          width: 1
        },
        textTransform: 'none',
        backgroundColor: '#2C3E50',
        padding: 15
      },
      {
        name: 'Beyaz Metin - Siyah Arka Plan',
        textColor: '#FFFFFF',
        fontSize: 48,
        fontFamily: 'Arial',
        fontWeight: 'bold',
        textBold: true,
        textItalic: false,
        textUnderline: false,
        textStrikethrough: false,
        textAlign: 'left',
        letterSpacing: 1,
        lineHeight: 1.2,
        textShadow: {
          enabled: true,
          color: '#000000',
          blur: 4,
          offsetX: 2,
          offsetY: 2
        },
        textStroke: {
          enabled: false,
          color: '#000000',
          width: 1
        },
        textTransform: 'none',
        backgroundColor: '#000000',
        padding: 15
      },
      {
        name: 'Koyu Metin - Turuncu Arka Plan',
        textColor: '#2C3E50',
        fontSize: 48,
        fontFamily: 'Arial',
        fontWeight: 'bold',
        textBold: true,
        textItalic: false,
        textUnderline: false,
        textStrikethrough: false,
        textAlign: 'left',
        letterSpacing: 1,
        lineHeight: 1.2,
        textShadow: {
          enabled: true,
          color: '#000000',
          blur: 4,
          offsetX: 2,
          offsetY: 2
        },
        textStroke: {
          enabled: false,
          color: '#000000',
          width: 1
        },
        textTransform: 'none',
        backgroundColor: '#FF6B35',
        padding: 15
      },
      {
        name: 'Beyaz Metin - Kırmızı Arka Plan',
        textColor: '#FFFFFF',
        fontSize: 48,
        fontFamily: 'Arial',
        fontWeight: 'bold',
        textBold: true,
        textItalic: false,
        textUnderline: false,
        textStrikethrough: false,
        textAlign: 'left',
        letterSpacing: 1,
        lineHeight: 1.2,
        textShadow: {
          enabled: true,
          color: '#000000',
          blur: 4,
          offsetX: 2,
          offsetY: 2
        },
        textStroke: {
          enabled: false,
          color: '#000000',
          width: 1
        },
        textTransform: 'none',
        backgroundColor: '#E74C3C',
        padding: 15
      },
      {
        name: 'Siyah Metin - Beyaz Arka Plan',
        textColor: '#000000',
        fontSize: 48,
        fontFamily: 'Arial',
        fontWeight: 'bold',
        textBold: true,
        textItalic: false,
        textUnderline: false,
        textStrikethrough: false,
        textAlign: 'left',
        letterSpacing: 1,
        lineHeight: 1.2,
        textShadow: {
          enabled: false,
          color: '#000000',
          blur: 0,
          offsetX: 0,
          offsetY: 0
        },
        textStroke: {
          enabled: false,
          color: '#000000',
          width: 1
        },
        textTransform: 'none',
        backgroundColor: '#FFFFFF',
        padding: 15
      }
    ],

    // History (Undo/Redo)
    history: [],
    historyIndex: -1,
    maxHistory: 50,

    // Zoom & Pan
    zoom: 1,
    panX: 0,
    panY: 0,
    isPanning: false,
    lastPanX: 0,
    lastPanY: 0,
    minZoom: 0.1,
    maxZoom: 10,

    // Filters & Adjustments
    brightness: 100,
    contrast: 100,
    saturation: 100,
    hue: 0,
    exposure: 0,

    // Crop data for desktop and mobile
    desktopCrop: [],
    mobileCrop: [],
    desktopFocus: 'center',
    mobileFocus: 'center',

    // Original image dimensions (before any crop operations)
    originalImageWidth: 0,
    originalImageHeight: 0,
    originalImagePath: null, // Store original image path for spot_data

    // Image metadata
    imageMeta: {},
    gamma: 1,
    blur: 0,
    sharpen: 0,

    // Crop
    cropStartX: 0,
    cropStartY: 0,
    cropEndX: 0,
    cropEndY: 0,
    isCropping: false,
    cropAspectRatio: null,

    // Transform
    isTransforming: false,
    transformHandle: null,
    transformStartX: 0,
    transformStartY: 0,

    // Selection
    selection: null,
    isSelecting: false,

    // UI State
    showLayersPanel: false,
    showHistoryPanel: false,
    showPropertiesPanel: true,
    showToolbar: true,
    showZoomSlider: false,

    // Keyboard shortcuts
    shortcuts: {},
  };
}

