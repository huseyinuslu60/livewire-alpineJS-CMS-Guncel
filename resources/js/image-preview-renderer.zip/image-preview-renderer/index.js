/**
 * Image Preview Renderer - Main Entry Point
 * Renders images with crop, effects, and textObjects from spot_data
 * Usage: Add data-has-spot-data="true" and data-spot-data attributes to img elements
 */

import { findSpotData, findPreviewCanvas, resolveImageSource } from './utils.js';
import { calculateCropRectangles, buildFilterString, renderTextObjects } from './rendering.js';

/**
 * Render preview image with spot_data (crop, effects, textObjects)
 * @param {HTMLElement} imgElement - The img element with spot_data attributes
 */
export function renderPreviewWithSpotData(imgElement) {
    // Validate imgElement
    if (!imgElement || !imgElement.tagName || imgElement.tagName !== 'IMG') {
        console.warn('Preview Renderer - Invalid imgElement:', imgElement);
        return;
    }

    // Find and parse spot_data
    const spotData = findSpotData(imgElement);
    if (!spotData || !spotData.image) {
        // No spot_data, show regular image
        const canvas = findPreviewCanvas(imgElement);
        if (canvas) {
            canvas.style.display = 'none';
        }
        if (imgElement) {
            imgElement.style.display = 'block';
        }
        return;
    }

    const imageData = spotData.image;

    // Find canvas element
    const canvas = findPreviewCanvas(imgElement);
    if (!canvas) {
        console.warn('Preview Renderer - Canvas not found for image:', imgElement.id);
        // Show regular image as fallback
        if (imgElement) {
            imgElement.style.display = 'block';
        }
        return;
    }

    // Resolve image source
    const imageSrc = resolveImageSource(imgElement, imageData);

    // Load and render image
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = function() {
        // Get container dimensions
        const container = imgElement.parentElement;
        let containerWidth = container ? container.clientWidth : 0;
        let containerHeight = container ? container.clientHeight : 0;

        // If container dimensions are 0, try to get from image element
        if (containerWidth === 0 || containerHeight === 0) {
            containerWidth = imgElement.clientWidth || imgElement.offsetWidth || 256;
            containerHeight = imgElement.clientHeight || imgElement.offsetHeight || 160;
        }

        // Ensure minimum dimensions
        if (containerWidth === 0) containerWidth = 256;
        if (containerHeight === 0) containerHeight = 160;

        // Set canvas size to match container
        canvas.width = containerWidth;
        canvas.height = containerHeight;
        canvas.style.display = 'block';
        imgElement.style.display = 'none';

        const ctx = canvas.getContext('2d');

        // CRITICAL: Clear canvas first to prevent showing old preview from other posts
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        // Get crop data
        const crop = imageData.variants?.desktop?.crop || imageData.variants?.mobile?.crop || null;
        const originalWidth = imageData.original?.width || img.width;
        const originalHeight = imageData.original?.height || img.height;

        // Calculate source and destination rectangles
        let sx = 0, sy = 0, sw = img.width, sh = img.height;
        let dx = 0, dy = 0, dw = canvas.width, dh = canvas.height;

        if (crop && Array.isArray(crop) && crop.length === 4 && crop[2] > 0 && crop[3] > 0) {
            const cropRects = calculateCropRectangles(
                crop, originalWidth, originalHeight,
                img.width, img.height,
                canvas.width, canvas.height
            );
            sx = cropRects.sx;
            sy = cropRects.sy;
            sw = cropRects.sw;
            sh = cropRects.sh;
            dx = cropRects.dx;
            dy = cropRects.dy;
            dw = cropRects.dw;
            dh = cropRects.dh;
        }

        // Apply effects
        const effects = imageData.effects || {};
        ctx.save();
        const filterString = buildFilterString(effects);
        if (filterString !== 'none') {
            ctx.filter = filterString;
        }

        // Draw cropped and filtered image
        ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
        ctx.restore();

        // Draw text objects
        const textObjects = imageData.textObjects || [];
        renderTextObjects(ctx, textObjects, imageData, dw, dh);
    };

    img.onerror = function() {
        console.error('Preview Renderer - Failed to load image:', imageSrc);
    };

    img.src = imageSrc;
}

/**
 * Process a single image element for preview rendering
 * IMPORTANT: Only process images that have their own spot_data attribute
 * Do NOT use parent element's spot_data, as it might belong to another post
 * @param {HTMLImageElement} img - Image element
 */
function processImageForPreview(img) {
    // CRITICAL: Only process if image has its own spot_data attribute
    // Do NOT search in parent elements, as this could apply wrong spot_data from another post
    const hasSpotData = img.getAttribute('data-has-spot-data') === 'true';
    const spotDataJson = img.getAttribute('data-spot-data');

    // Validate spot_data exists and is valid
    if (!hasSpotData || !spotDataJson || spotDataJson.length < 50) {
        // No valid spot_data on this image, skip it
        return;
    }

    // Validate spot_data is valid JSON
    try {
        const parsed = JSON.parse(spotDataJson);
        if (!parsed || !parsed.image) {
            // Invalid spot_data structure, skip it
            return;
        }
    } catch (e) {
        // Invalid JSON, skip it
        return;
    }

    // Image has valid spot_data, render it
    renderImagePreview(img);
}

/**
 * Render image preview (handle loading state)
 * @param {HTMLImageElement} img - Image element
 */
function renderImagePreview(img) {
    if (img.complete) {
        // Image already loaded, render immediately
        renderPreviewWithSpotData(img);
    } else {
        // Image not loaded yet, wait for load event
        img.addEventListener('load', function() {
            renderPreviewWithSpotData(this);
        }, { once: true });
    }
}

/**
 * Initialize preview renderer for all images with spot_data
 * IMPORTANT: Only processes images that have their own valid spot_data attribute
 * Call this after DOM is loaded or after Livewire updates
 */
export function initPreviewRenderer() {
    // Find all IMG elements with spot_data attribute (must be IMG elements, not other elements)
    const imagesWithSpotData = document.querySelectorAll('img[data-has-spot-data="true"][data-spot-data]');

    // Process each image that has valid spot_data
    imagesWithSpotData.forEach(img => {
        // Verify it's actually an IMG element
        if (img.tagName !== 'IMG') {
            return;
        }

        // Verify spot_data exists and is valid
        const spotDataJson = img.getAttribute('data-spot-data');
        if (!spotDataJson || spotDataJson.length < 50) {
            return;
        }

        // Process this image
        processImageForPreview(img);
    });

    // Also check preview-img-* images that might not have data-has-spot-data set yet
    // But only if they have data-spot-data attribute
    const previewImages = document.querySelectorAll('img[id^="preview-img-"][data-spot-data]');
    previewImages.forEach(img => {
        // Skip if already processed
        if (imagesWithSpotData.includes(img)) {
            return;
        }

        // Verify spot_data exists and is valid
        const spotDataJson = img.getAttribute('data-spot-data');
        if (!spotDataJson || spotDataJson.length < 50) {
            return;
        }

        // Set data-has-spot-data if not set
        if (img.getAttribute('data-has-spot-data') !== 'true') {
            img.setAttribute('data-has-spot-data', 'true');
        }

        // Process this image
        processImageForPreview(img);
    });
}

/**
 * Setup event listeners for Livewire and custom events
 */
function setupEventListeners() {
    // Re-render on Livewire update
    const livewireEvents = ['livewire:update', 'livewire:updated', 'livewire:load'];
    const renderDelays = [100, 300, 600]; // Multiple delays to catch elements created at different times

    livewireEvents.forEach(eventName => {
        document.addEventListener(eventName, function() {
            renderDelays.forEach(delay => {
                setTimeout(() => initPreviewRenderer(), delay);
            });
        });
    });

    // Listen for custom image-edited event
    document.addEventListener('image-edited', function() {
        const customDelays = [200, 500, 800];
        customDelays.forEach(delay => {
            setTimeout(() => initPreviewRenderer(), delay);
        });
    });
}

// Auto-initialize on DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPreviewRenderer);
} else {
    initPreviewRenderer();
}

// Setup event listeners
setupEventListeners();

// Make functions available globally for inline onload handlers and external calls
window.renderPreviewWithSpotData = renderPreviewWithSpotData;
window.initPreviewRenderer = initPreviewRenderer;

