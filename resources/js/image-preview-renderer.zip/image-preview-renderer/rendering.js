/**
 * Image Preview Renderer - Rendering Functions
 * Core rendering logic for crop, effects, and text objects
 */

/**
 * Calculate crop coordinates and destination rectangle
 * @param {Array} crop - Crop array [x, y, width, height]
 * @param {number} originalWidth - Original image width
 * @param {number} originalHeight - Original image height
 * @param {number} imgWidth - Loaded image width
 * @param {number} imgHeight - Loaded image height
 * @param {number} canvasWidth - Canvas width
 * @param {number} canvasHeight - Canvas height
 * @returns {object} Source and destination rectangles
 */
export function calculateCropRectangles(crop, originalWidth, originalHeight, imgWidth, imgHeight, canvasWidth, canvasHeight) {
    const [cropX, cropY, cropWidth, cropHeight] = crop;

    // Ensure crop coordinates are within image bounds
    const maxX = Math.min(cropX + cropWidth, originalWidth);
    const maxY = Math.min(cropY + cropHeight, originalHeight);
    const finalCropX = Math.max(0, Math.min(cropX, originalWidth));
    const finalCropY = Math.max(0, Math.min(cropY, originalHeight));
    const finalCropWidth = Math.max(1, maxX - finalCropX);
    const finalCropHeight = Math.max(1, maxY - finalCropY);

    // Calculate scale factor from original image to loaded image
    const scaleX = imgWidth / originalWidth;
    const scaleY = imgHeight / originalHeight;

    // Convert crop coordinates from original image to loaded image coordinates
    let sx = finalCropX * scaleX;
    let sy = finalCropY * scaleY;
    let sw = finalCropWidth * scaleX;
    let sh = finalCropHeight * scaleY;

    // Ensure source coordinates are within image bounds
    sx = Math.max(0, Math.min(sx, imgWidth));
    sy = Math.max(0, Math.min(sy, imgHeight));
    sw = Math.max(1, Math.min(sw, imgWidth - sx));
    sh = Math.max(1, Math.min(sh, imgHeight - sy));

    // Maintain aspect ratio when scaling to canvas
    const cropAspect = sw / sh;
    const canvasAspect = canvasWidth / canvasHeight;

    let dw, dh, dx, dy;
    if (cropAspect > canvasAspect) {
        // Crop is wider - fit to canvas width
        dw = canvasWidth;
        dh = canvasWidth / cropAspect;
    } else {
        // Crop is taller - fit to canvas height
        dh = canvasHeight;
        dw = canvasHeight * cropAspect;
    }

    // Center the cropped image in canvas
    dx = (canvasWidth - dw) / 2;
    dy = (canvasHeight - dh) / 2;

    return { sx, sy, sw, sh, dx, dy, dw, dh };
}

/**
 * Build CSS filter string from effects
 * @param {object} effects - Effects object
 * @returns {string} CSS filter string
 */
export function buildFilterString(effects) {
    const filters = [];

    if (effects.brightness !== undefined && effects.brightness !== 100) {
        filters.push(`brightness(${effects.brightness}%)`);
    }
    if (effects.contrast !== undefined && effects.contrast !== 100) {
        filters.push(`contrast(${effects.contrast}%)`);
    }
    if (effects.saturation !== undefined && effects.saturation !== 100) {
        filters.push(`saturate(${effects.saturation}%)`);
    }
    if (effects.hue !== undefined && effects.hue !== 0) {
        filters.push(`hue-rotate(${effects.hue}deg)`);
    }
    if (effects.blur !== undefined && effects.blur > 0) {
        filters.push(`blur(${effects.blur}px)`);
    }

    return filters.length > 0 ? filters.join(' ') : 'none';
}

/**
 * Render text objects on canvas
 * @param {CanvasRenderingContext2D} ctx - Canvas context
 * @param {Array} textObjects - Array of text objects
 * @param {object} imageData - Image data from spot_data
 * @param {number} dw - Destination width
 * @param {number} dh - Destination height
 */
export function renderTextObjects(ctx, textObjects, imageData, dw, dh) {
    if (!textObjects || textObjects.length === 0) {
        return;
    }

    // Get saved canvas dimensions
    const savedCanvas = imageData.canvas || {};
    const savedCanvasWidth = savedCanvas.width || imageData.original?.width || dw;
    const savedCanvasHeight = savedCanvas.height || imageData.original?.height || dh;

    // Calculate scale from saved canvas to preview canvas
    const textScaleX = dw / savedCanvasWidth;
    const textScaleY = dh / savedCanvasHeight;
    const textScale = Math.min(textScaleX, textScaleY);

    textObjects.forEach(textObj => {
        ctx.save();

        // Scale text position and size from saved canvas to preview canvas
        const textX = (textObj.x / savedCanvasWidth) * dw;
        const textY = (textObj.y / savedCanvasHeight) * dh;
        const fontSize = (textObj.fontSize || 32) * textScale;

        // Set font properties
        const fontStyle = textObj.textItalic ? 'italic ' : '';
        const fontWeight = textObj.textBold ? 'bold ' : '';
        ctx.font = `${fontStyle}${fontWeight}${fontSize}px ${textObj.fontFamily || 'Arial'}`;
        ctx.fillStyle = textObj.color || textObj.textColor || '#000000';
        ctx.textAlign = textObj.textAlign || 'left';
        ctx.textBaseline = 'top';

        // Draw text background if needed
        if (textObj.backgroundColor && textObj.backgroundColor !== 'transparent') {
            const metrics = ctx.measureText(textObj.text || '');
            const padding = textObj.padding || 0;
            ctx.fillStyle = textObj.backgroundColor;
            ctx.fillRect(
                textX - padding,
                textY - padding,
                metrics.width + (padding * 2),
                fontSize + (padding * 2)
            );
        }

        // Draw text
        ctx.fillStyle = textObj.color || textObj.textColor || '#000000';
        ctx.fillText(textObj.text || '', textX, textY);

        ctx.restore();
    });
}

