/**
 * Image Preview Renderer - Utility Functions
 * Helper functions for finding and parsing spot_data
 */

/**
 * Find and parse spot_data from img element
 * IMPORTANT: Only use spot_data from the img element itself, NOT from parent elements
 * This prevents applying wrong spot_data from another post
 * @param {HTMLElement} imgElement - The img element
 * @returns {object|null} Parsed spot_data or null
 */
export function findSpotData(imgElement) {
    // CRITICAL: Only use spot_data from the img element itself
    // Do NOT search in parent elements, as this could apply wrong spot_data from another post
    const hasSpotData = imgElement.getAttribute('data-has-spot-data') === 'true';
    const spotDataJson = imgElement.getAttribute('data-spot-data');

    if (!hasSpotData || !spotDataJson || spotDataJson.length < 50) {
        // No valid spot_data on this image
        return null;
    }

    try {
        const spotData = JSON.parse(spotDataJson);
        // Validate structure
        if (!spotData || !spotData.image) {
            return null;
        }
        return spotData;
    } catch (e) {
        console.error('Preview Renderer - Failed to parse spot_data:', e);
        return null;
    }
}

/**
 * Find canvas element for preview rendering
 * IMPORTANT: Must find the EXACT canvas matching the img element
 * Do NOT return random canvas, as this would show wrong preview
 * @param {HTMLElement} imgElement - The img element
 * @returns {HTMLCanvasElement|null} Canvas element or null
 */
export function findPreviewCanvas(imgElement) {
    // First try to find canvas by ID matching img ID (most specific)
    const imgId = imgElement.id;
    if (imgId && imgId.startsWith('preview-img-')) {
        const fileId = imgId.replace('preview-img-', '');
        const canvasId = `preview-canvas-${fileId}`;
        const canvas = document.getElementById(canvasId);
        if (canvas) {
            return canvas;
        }
    }

    // Try to find canvas by data-file-id matching img's data-file-id
    const imgFileId = imgElement.getAttribute('data-file-id');
    if (imgFileId) {
        const canvasId = `preview-canvas-${imgFileId}`;
        const canvas = document.getElementById(canvasId);
        if (canvas) {
            return canvas;
        }
    }

    // Try to find canvas by data-file-index matching img's data-file-index
    const fileIndex = imgElement.getAttribute('data-file-index');
    if (fileIndex !== null && fileIndex !== undefined) {
        const canvasId = `preview-canvas-index-${fileIndex}`;
        const canvas = document.getElementById(canvasId);
        if (canvas) {
            return canvas;
        }

        // Also try in parent element
        const parent = imgElement.parentElement;
        if (parent) {
            const canvas = parent.querySelector(`canvas#preview-canvas-index-${fileIndex}`);
            if (canvas) {
                return canvas;
            }
        }
    }

    // Try to find canvas in the same parent element (should be sibling)
    const parent = imgElement.parentElement;
    if (parent) {
        // Look for canvas with matching ID pattern
        if (imgId && imgId.startsWith('preview-img-')) {
            const fileId = imgId.replace('preview-img-', '');
            const canvas = parent.querySelector(`canvas#preview-canvas-${fileId}`);
            if (canvas) {
                return canvas;
            }
        }
        // Look for any canvas in parent (should be sibling of img)
        const canvas = parent.querySelector('canvas[id^="preview-canvas-"]');
        if (canvas) {
            return canvas;
        }
    }

    // CRITICAL: Do NOT return random canvas from document
    // This would cause wrong preview to show for other posts
    console.warn('Preview Renderer - Could not find matching canvas for image:', imgElement.id);
    return null;
}

/**
 * Resolve image source URL from spot_data or img element
 * @param {HTMLElement} imgElement - The img element
 * @param {object} imageData - Image data from spot_data
 * @returns {string} Image source URL
 */
export function resolveImageSource(imgElement, imageData) {
    const originalPath = imageData.original?.path;
    if (originalPath) {
        return originalPath.startsWith('http')
            ? originalPath
            : `${window.location.origin}/storage/${originalPath}`;
    }
    return imgElement.src;
}

